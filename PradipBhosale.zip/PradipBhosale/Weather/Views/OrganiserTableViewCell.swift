//
//  OrganiserTableViewCell.swift
//  Weather
//
//  Created by Pradip Bhosale on 06/11/2019.
//  Copyright © 2019 Pradip Bhosale. All rights reserved.
//

import UIKit
import WeatherFrontKit

class OrganiserTableViewCell: UITableViewCell {
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var subNameLabel: UILabel!

    @IBOutlet weak var nameTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var subNameTrailingContraint: NSLayoutConstraint!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        self.backgroundColor = UIColor.clear
    }
}
