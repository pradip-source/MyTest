
## Features

* Dark Sky API integration.
* Google Places Autocomplete API integration.
* JSON Parsing.
* Custom UI Drawing and Animations.
* Today Extension (Notification Center Widget).
* Embedded Framework usage for code shared between app and widget.
* Core Data.
* Core Location.
* Unit Tests.
* [FontAwesome](http://fontawesome.io) and [Weather Icons](http://erikflowers.github.io/weather-icons/) usage.

## Requirements
* iOS 10+
* Xcode 9
* Swift 4

## Project Setup

1. Head to [Dark Sky](https://darksky.net/dev), sign-up and get an API key.
2. Head to the [Google Places API](https://developers.google.com/places/ios-api/), sign-up and get an API key.
3. Open **Constants.swift** under **WeatherKit** replace the strings with your API keys.

```
public static let darkSkyAPIKey = "ENTER_YOUR_DARK_SKY_KEY"
public static let googleAPIKey = "ENTER_YOUR_GOOGLE_PLACES_KEY"
```

4. Build the project and either run in a simulator or device.

## Acknowledgements
* The app's weather data is provided by [Dark Sky](https://darksky.net/dev).
* The weather icons are provided by [Weather Icons](http://erikflowers.github.io/weather-icons/).
* The location autocomplete data is provided by [Google Places](https://developers.google.com/places/ios-api/).

