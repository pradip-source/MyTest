//
//  UnitManager.swift
//  WeatherFrontKit
//
//  Created by Pradip Bhosale on 06/11/2019.
//  Copyright © 2017 Pradip Bhosale. All rights reserved.
//

import UIKit

open class UnitManager: NSObject {

    open class func celsius(fahrenheit: Float) -> Float {
        return (fahrenheit - 32.0) * (5/9)
    }

    open class func kph(mph: Float) -> Float {
        return mph * 1.609344
    }
}
