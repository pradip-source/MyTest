//
//  UnitManagerTests.swift
//  WeatherTests
//
//  Created by Pradip Bhosale on 06/11/2019.
//  Copyright © 2017 Pradip Bhosale. All rights reserved.
//

import XCTest
@testable import WeatherFrontKit

class UnitManagerTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
    }

    func testKPH() {
        let kph = UnitManager.kph(mph: 1.0)
        XCTAssertEqual(kph, 1.609344)
    }

    func testCelsius() {
        let celsius = UnitManager.celsius(fahrenheit: 32.0)
        XCTAssertEqual(celsius, 0.0)
    }
}
