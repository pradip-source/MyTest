//
//  SettingsManagerTests.swift
//  WeatherTests
//
//  Created by Pradip Bhosale on 06/11/2019.
//  Copyright © 2017 Pradip Bhosale. All rights reserved.
//

import XCTest
@testable import WeatherFrontKit

class SettingsManagerTests: XCTestCase {
    
    override func setUp() {
        super.setUp()

        SettingsManager.setup()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    func testSetTemperatureCelsius() {
        SettingsManager.setTemperature(celsius: true)

        let celsius = SettingsManager.isCelsius()
        XCTAssertTrue(celsius)
    }

    func testSetSpeedMPH() {
        SettingsManager.setSpeed(mph: true)

        let mph = SettingsManager.isMPH()
        XCTAssertTrue(mph)
    }

    func testSetPageIndex() {
        SettingsManager.setPageIndex(index: 1)

        let pageIndex = SettingsManager.pageIndex()
        XCTAssertEqual(pageIndex, 1)
    }

    func testSetWidgetExpanded() {
        SettingsManager.setWidgetExpanded(expanded: true)

        let widgetExpanded = SettingsManager.widgetExpanded()
        XCTAssertTrue(widgetExpanded)
    }
}
